﻿//TODO :  Move route logic to app.js file
//TODO : Add package.json file
//TODO : Add bower.json file
//TODO : Add gulf.js to build and configure riotjs

$(function () {

    var PCNews = PCNews || {};

    window.articleApiUrl = "http://localhost:9000/api/Articles/";
});
